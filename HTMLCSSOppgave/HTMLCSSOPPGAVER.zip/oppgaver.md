1. Endre størrelsen på teksten ved bruk av ID
2. Endre font familie
3. Endre innhold i teksten
4. Bruke klasser til å endre størrelse på begge tekstene samtidig
5. Legge til et bilde i html dokumentet
6. Endre størrelse på bildet ved hjelp av CSS styling
Ekstra. Hvis du har tid, gjør hva du vil med CSS og HTML